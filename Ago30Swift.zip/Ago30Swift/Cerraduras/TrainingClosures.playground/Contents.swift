func calcular(a:Int, b:Int, operacion:(Int,Int)->Int){
    print("El resultado es \(operacion(a,b))")
}
func funcionCulaquiera(closure: ()-> Void){
    
}
//llamando a la funcion sin usar trailing Closietr
funcionCulaquiera(closure: {
    //codigo
})
//llamando a la funcion con training clousre
funcionCulaquiera {
    //codigo
}
//usando trailing closure sin los parentesis
funcionCulaquiera {
    //codigo
}
//codigo
calcular (a: 6, b: 10){ $0 + $1 }
