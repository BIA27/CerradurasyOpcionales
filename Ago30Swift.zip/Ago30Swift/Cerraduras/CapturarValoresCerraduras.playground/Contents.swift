//capturando valores usando cerraduras
func hacerIncremento(en cantidad:Int) -> Int{
    var total = 0
    func incrementar() -> Int{
        total += cantidad
        return total
    }
    return incrementar()
}
let incrementarPorDiez = hacerIncremento(en: 10)
