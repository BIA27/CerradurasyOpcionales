func calcular(a:Int, b:Int, operacion:(Int,Int)->Int){
    print("El resultado es \(operacion(a,b))")
}
func sumar(a:Int,b:Int) -> Int{
    return a+b
}
calcular(a:6 , b: 10, operacion: sumar)
//Devuelve el resultado es 16
