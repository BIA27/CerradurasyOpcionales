func sumarDosNumeros(_ a: Int, _ b: Int) -> Int
{
    return a + b
}
func multiplicarDosNumeros(_ a: Int, _ b:Int) -> Int{
    return a*b
}
var calculo:(Int,Int) -> Int = sumarDosNumeros
print("El resultado de sumar 3+7 es\(calculo(3,7))")
calculo = multiplicarDosNumeros
print("El resultado de multiplicar 3x7 es\(calculo(3,7))")
//El resultado de multiplicar 3x7 es 21
func imprimirResultado(_ operacion:(Int,Int) -> Int, _ a:Int, _ b:Int)
{
    print("El resultado es\(operacion(a,b))")
}
imprimirResultado(sumarDosNumeros, 10,60)
//Devuelve resultado es 70
