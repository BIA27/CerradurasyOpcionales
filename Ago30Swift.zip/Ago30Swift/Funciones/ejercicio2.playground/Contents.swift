//funciones con parametros
func saludar(nombre: String){
    print("Hola\(nombre)!")
    
    
}
saludar(nombre: "Gabriel")
//Devuelve:
//Hola Gabriel!

