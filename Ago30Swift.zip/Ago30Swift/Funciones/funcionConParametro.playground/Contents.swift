//funcion con un parametro y un valor de retorno
func saludarA(nombre: String) -> String{
    return "Hola \(nombre)!"
}
let saludo = saludarA(nombre: "Gabriel")
print(saludo)
//devuelve hola gabriel 

