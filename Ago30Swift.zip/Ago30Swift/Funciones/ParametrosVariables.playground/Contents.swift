//Parametros variadicos
func sumar(numeros:Int...) -> Int {
    var suma:Int=0
    for valor in numeros{
        suma = suma+valor
    }
    return suma
}
print("La suma es igual a \(sumar(numeros: 4,6,2,3,10,6,7,5,4))")
//devuelve
//La suma es igual a 47
