//funcion que devuelve mas de un dato
func minMax(array: [Int]) -> (min: Int, max: Int){
    var minimo = array[0]
    var maximo = array[0]
    for valor in array[1..<array.count]{
        if valor < minimo {minimo = valor} else if valor > maximo{
            maximo = valor
        }
    }
    return (minimo, maximo)
}
let notas = minMax(array: [1,2,10,8,5])
print("La nota mas baja es \(notas.min) y la mas alta es \(notas.max)")
//devuelve
//la nota mas baja es 1 y las mas alta es 10
