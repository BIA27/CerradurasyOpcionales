//parametros inout
func cambiarDosEnteros(_ a: inout Int, _ b: inout Int){
    let auxiliar = a
    a=b
    b=auxiliar
    
}
var numero1 = 5
var numero2 = 8
print("Numero1:\(numero1)")
print("numero2:\(numero2)")
cambiarDosEnteros(&numero1, &numero2)
print("Numero1: \(numero1)")
print("Numero2: \(numero2)")

//devulve
//numero1: 5
//numero:8
