//funciones con parametros
func saludar(nombre: String, edad: Int){
    print("felices \(edad) anos\(nombre)!")
}

saludar(nombre: "Gabriel", edad:  29)

//Devuelve
//Felices 29 anos Gabriel!
