

//parametros por defecto
func saludar(a nombre:String, cumpleAnos:Bool = false) {
    if cumpleAnos{
        print("Feliz cumpleanos\(nombre)")
    }else{
        print("Buen dia\(nombre)")
    }
}
saludar(a: "Gabriel", cumpleAnos: true)
saludar(a: "Gabriel")
//devuelve feliz cumplanos gabriel
//buen dia gabriel
