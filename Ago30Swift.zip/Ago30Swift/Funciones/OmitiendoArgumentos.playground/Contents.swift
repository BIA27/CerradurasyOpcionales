//Omitiendo argumento label
func sumar(_ primerNumero: Int, _ segundoNumero: Int) -> Int
{
    return primerNumero + segundoNumero
}

print("El resultado de 4 + 5 es \(sumar(4, 5))")


//Devuelve:
//El resultado de 4 + 5 es 9
