func saludar (){
    print("Hola mundo!")
}
saludar()
//devuelve Hola mundo!
