//Etiquetas de argumento
func saludar(a nombre: String, porCumplir edad: Int){
    print("Felicidades \(edad) anos \(nombre)!")
}
saludar(a: "Gabriel", porCumplir: 30)
//Devuelve
//Felices 30 anos Gabriel

